const coupons = require('../models/coupons')

//function to check existance of coupon List return False if exists
const checUserCouponsList = async (email) => {
    let userCouponsList = await coupons.findOne({ email });
    return userCouponsList ? false : true;
};

const addToExistingCouponList = async (req, res) => {
    coupons.findOneAndUpdate({ email: req.body.email }, {
        $push: {
            coupons: { ...req.body,
                couponCode:req.body.couponCode
            }
        }
    }, (err, docs) => {
        if (!err) {
            res.json({
                message:"Added New Coupon",
                success:true
            })
        }
    })
}
const createNewCoupon = async (req, res) => {
    if (req.body.AdminPassword == "@CBD$2021@") {
        const newcoupon = new coupons({
            ...req.body,
            coupons: { ...req.body }

        })
        await newcoupon.save((err, docs) => {
            if (!err) {
                res.json({
                    message: `Coupon Created`,
                    success: true
                })
            }
            else {
                res.json({
                    message: `Error:- ${err}`,
                    success: false
                })
            }
        })
    }
}

const getUserCoupons=(req,res)=>{
    coupons.findOne({email:req.body.email},(err,docs)=>{
        if(docs){
            res.json({
                message:"User Coupons",
                success:true,
                data:docs.coupons
            })
        }
    })
}



module.exports = {
    checUserCouponsList,
    addToExistingCouponList,
    createNewCoupon,
    getUserCoupons
};