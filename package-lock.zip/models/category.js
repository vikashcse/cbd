const { Schema, model } = require("mongoose");

const category = new Schema(
  {
    categoryName: {
      type: String,
      required: true
    },
    parent: {
      type: String,
  
    },
    categoryDescription: {
      type: String
    
    },
    sortOrder: {
      type: Number
    },
    categoryImage: {
      type: String
    },
    status:{
      type: String
   
    }
  },
  { timestamps: true }
);

module.exports = model("category", category);
