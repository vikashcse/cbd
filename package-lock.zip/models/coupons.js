const { Schema, model } = require("mongoose");

const coupons = new Schema(
    {
        email: {
            type: String,
            required: true
        },
        coupons: [
            {
                couponCode: {
                    type: String,
                    required: true
                },
                discount: { type: Number, default: 0, require: true },
                expire: { type: Date, require: true },
                productID:{type: String}
            }
        ]


    }
);

module.exports = model("coupons", coupons);
