const { Schema, model } = require("mongoose");

const notification = new Schema(
  {
    email: {
      type: String,
      required: true
    },
    notification:[]
  },
  { timestamps: true }
);

module.exports = model("notification", notification);
