const authenticator = require('authenticator');
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const passport = require("passport");
const resetPass=require("../models/ResetPassword");
const { SECRET } = require("../config");

const products=require("../models/products")
const banner =require("../models/banner")



/**
 * @DESC To Insert Product
 */
const insert_product = async (userDets,filename, res) => {
  var sale_price=0
  var discount=0
  try {
    //console.log(userDets)
    if(userDets.discount==""){
      sale_price=userDets.price
      discount=0
    }
    else{
      sale_price=userDets.price*((100-userDets.discount)/100)
      discount=userDets.discount
    }


        // create a new user
    const newProduct = new products({
      ...userDets,
      image:filename,
      sale_price:sale_price,
      discount:discount
    });

    await newProduct.save((err,docs)=>{
      if(!err){
        return res.json({
          message: "Product Added Successfull.",
          success: true
        });
      }
      else{
        return res.json({
          message: "Unable to create your product.",
          success: false
        });
      }
    });


  } catch (err) {
    console.log(err)
    // Implement logger function (winston)
    return res.json({
      message: "Unable to create your product.",
      success: false
    });
  }
};

const get_products= async (res)=>{
  all = await products.find((err, docs) => {
    if (!err) {
      res.send(docs);
      return docs;
      console.log(docs);
    }
    else { console.log('Error:' + JSON.stringify(err, undefined, 2)); }
  });
  //console.log(all)
};

const delete_product = async (id,res)=>{
  console.log(id)
  await products.findByIdAndDelete({_id:id},(err,docs)=>{
    if(!err){
      res.status(200).json({
        message: "Delet Successfull.",
        success: true
      });
    }
    else{
      res.status(200).json({
        message: `Error :-${err}`,
        success: false
      });
    }
  })
}

const CreateBanner =async (req,res)=>{
  bannerImage=String(req.protocol+"://"+req.hostname+":5000/"+req.file.destination+req.file.originalname)
  console.log(req.protocol+"://"+req.hostname+":5000/"+req.file.destination+req.file.originalname)
  const bannerLink = new banner({banner:bannerImage})
  bannerLink.save((err,docs)=>{
    if(!err){
      console.log(docs)
      res.status(200).json({
        message: `Banner Added Successfull`,
        success: true
      });
    }
    else{
      res.status(200).json({
        message: `Error:- ${err}`,
        success: true
      });
    }
  })
}

const getBanner =async (res)=>{
  banner.find((err,docs)=>{
    if(!err){
      console.log(docs)
      res.send(docs)
    }
    else{console.log(err)}
  })
}

const deleteBanner=async(req,res)=>{
  banner.findByIdAndDelete({_id:req.body.id},(err,docs)=>{
    if(!err){
      res.status(200).json({
        message: `Delete Successfull`,
        success: true
      });
    }
    else{
      res.status(200).json({
        message: `Error :-${err}`,
        success: false
      });
    }
  })
}


const search=async(req,res)=>{
  products.find({ $text: { $search: req.body.search } }
    , (err, docs) => {
      if (!err) {
        res.json({
          message:"Searched Product.",
          success:true,
          data:docs
        })
      }
      else {
        res.json({
          message:"Product Not found.",
          success:false
        })
      }
    }
  )



}


module.exports = {
    insert_product,
    get_products,
    delete_product,
    CreateBanner,
    getBanner,
    deleteBanner,
    search
};
