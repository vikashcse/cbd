const coupons = require('../models/coupons')

//function to check existance of coupon List return False if exists
const checUserCouponsList = async (email) => {
    let userCouponsList = await coupons.findOne({ email });
    return userCouponsList ? false : true;
};

const addToExistingCouponList = async (req, res) => {
    coupons.findOneAndUpdate({ email: req.body.email }, {
        $push: {
            coupons: { ...req.body,
                couponCode:req.body.couponCode
            }
        }
    }, (err, docs) => {
        if (!err) {
            res.json({
                message:"Added New Coupon",
                success:true
            })
        }
    })
}
const createNewCoupon = async (req, res) => {
    if (req.body.AdminPassword == "@CBD$2021@") {
        const newcoupon = new coupons({
            ...req.body,
            coupons: { ...req.body }

        })
        await newcoupon.save((err, docs) => {
            if (!err) {
                res.json({
                    message: `Coupon Created`,
                    success: true
                })
            }
            else {
                res.json({
                    message: `Error:- ${err}`,
                    success: false
                })
            }
        })
    }
}

const getUserCoupons=(req,res)=>{
    coupons.findOne({email:req.body.email},(err,docs)=>{
        if(docs){
            res.json({
                message:"User Coupons",
                success:true,
                data:docs.coupons
            })
        }
        else if(!docs){
            res.json({
                message:"No Coupons",
                success:false,
            })
        }
        else{
            res.json({
                message:`Error:- ${err}`,
                success:false,
            })
        }
    })
}

const validateCoupon=(req,res)=>{
    coupons.findOne({email:req.body.email},{
       
            coupons: { $elemMatch:{ _id:req.body.id }
        }
    },(err,docs)=>{
        if(docs.coupons[0]){
            //console.log(docs.coupons[0])
            res.json({
                message:`Match Successfull`,
                success:true,
                data:docs.coupons[0]
            })
        }
        else if(!docs.coupons[0]){
            //console.log("no docs")
            res.json({
                message:`Coupon Not Matched.`,
                success:false,
            })
        }
        else{
            //console.log(err)
            res.json({
                message:`Error:- ${err}`,
                success:false,
            })
        }
    })
}

const deletCoupons=async(req,res)=>{
    await coupons.findOneAndDelete({email:req.body.email},(err,docs)=>{
        if(docs){
            res.json({
                message:`Delet Successfull`,
                success:false,
            })
        }
        else if(!docs){
            res.json({
                message:`Nothing To Delet`,
                success:false,
            })
        }
        else{
            res.json({
                message:`Error:- ${err}`,
                success:false,
            })
        }
    })
}

module.exports = {
    checUserCouponsList,
    addToExistingCouponList,
    createNewCoupon,
    getUserCoupons,
    validateCoupon,
    deletCoupons
};