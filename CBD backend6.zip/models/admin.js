const { Schema, model } = require("mongoose");

const admin = new Schema(
  {
    email: {
      type: String,
      required: true
    },
    name: {
      type: String,
  
    },
    password: {
      type: String,
      required: true
    }
  },
  { timestamps: true }
);

module.exports = model("admin", admin);
